import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/index.dart';
import 'filtret_lapa_widget.dart' show FiltretLapaWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FiltretLapaModel extends FlutterFlowModel<FiltretLapaWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for RadioButton1 widget.
  FormFieldController<String>? radioButton1ValueController;
  // State field(s) for RadioButton2 widget.
  FormFieldController<String>? radioButton2ValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  /// Additional helper methods.
  String? get radioButton1Value => radioButton1ValueController?.value;
  String? get radioButton2Value => radioButton2ValueController?.value;
}
