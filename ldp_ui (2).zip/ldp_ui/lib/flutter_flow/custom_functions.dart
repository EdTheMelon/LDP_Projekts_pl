import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String? iegutNosaukumu(
  int kart,
  int filt,
  int rowNum,
) {
  String nosaukums = "null";

  if (kart == 0) {
    if (filt == 0) {
      switch (rowNum) {
        case 1:
          nosaukums = "Baltmaize";
          break;
        case 2:
          nosaukums = "Baltmaize";
          break;
        case 3:
          nosaukums = "Baltmaize";
          break;
        case 4:
          nosaukums = "Holandes siers";
          break;
        case 5:
          nosaukums = "Holandes siers";
          break;
        case 6:
          nosaukums = "Holandes siers";
          break;
        case 7:
          nosaukums = "Ābolu sula";
          break;
        case 8:
          nosaukums = "Ābolu sula";
          break;
        case 9:
          nosaukums = "Ābolu sula";
          break;
        case 10:
          nosaukums = "Vīnogu sula";
          break;
      }
    } else if (filt == 1) {
      switch (rowNum) {
        case 1:
          nosaukums = "Baltmaize";
          break;
        case 2:
          nosaukums = "Holandes siers";
          break;
        case 3:
          nosaukums = "Ābolu sula";
          break;
        case 4:
          nosaukums = "Vīnogu sula";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 2 || filt == 3) {
      switch (rowNum) {
        case 1:
          nosaukums = "Baltmaize";
          break;
        case 2:
          nosaukums = "Holandes siers";
          break;
        case 3:
          nosaukums = "Ābolu sula";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 4) {
      switch (rowNum) {
        case 1:
        case 2:
        case 3:
          nosaukums = "Baltmaize";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 5) {
      switch (rowNum) {
        case 1:
        case 2:
        case 3:
          nosaukums = "Holandes siers";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 6) {
      switch (rowNum) {
        case 1:
        case 2:
        case 3:
          nosaukums = "Ābolu sula";
          break;
        case 4:
          nosaukums = "Vīnogu sula";
          break;
        default:
          nosaukums = " ";
          break;
      }
    }
  } else if (kart == 1) {
    switch (rowNum) {
      case 1:
      case 2:
      case 3:
        nosaukums = "Baltmaize";
        break;
      case 4:
      case 5:
      case 6:
        nosaukums = "Holandes siers";
        break;
      case 7:
      case 8:
      case 9:
        nosaukums = "Ābolu sula";
        break;
      case 10:
        nosaukums = "Vīnogu sula";
        break;
    }
  } else if (kart == 2) {
    switch (rowNum) {
      case 1:
      case 5:
      case 8:
        nosaukums = "Baltmaize";
        break;
      case 2:
      case 6:
      case 9:
        nosaukums = "Holandes siers";
        break;
      case 3:
      case 7:
      case 10:
        nosaukums = "Ābolu sula";
        break;
      case 4:
        nosaukums = "Vīnogu sula";
        break;
    }
  } else if (kart == 3) {
    switch (rowNum) {
      case 1:
      case 3:
      case 7:
        nosaukums = "Baltmaize";
        break;
      case 2:
      case 4:
      case 5:
        nosaukums = "Holandes siers";
        break;
      case 6:
      case 8:
      case 9:
        nosaukums = "Ābolu sula";
        break;
      case 10:
        nosaukums = "Vīnogu sula";
        break;
    }
  } else if (kart == 4) {
    switch (rowNum) {
      case 1:
      case 2:
      case 3:
        nosaukums = "Ābolu sula";
        break;
      case 4:
      case 5:
      case 6:
        nosaukums = "Baltmaize";
        break;
      case 7:
      case 8:
      case 9:
        nosaukums = "Holandes siers";
        break;
      case 10:
        nosaukums = "Vīnogu sula";
        break;
    }
  }

  return nosaukums;
}

String? iegutCenu(
  int kart,
  int filt,
  int rowNum,
) {
  String nosaukums = " ";

  if (kart == 0) {
    if (filt == 0) {
      switch (rowNum) {
        case 1:
          nosaukums = "0.70";
          break;
        case 2:
          nosaukums = "0.80";
          break;
        case 3:
          nosaukums = "0.99";
          break;
        case 4:
          nosaukums = "1.45";
          break;
        case 5:
          nosaukums = "2.20";
          break;
        case 6:
          nosaukums = "1.80";
          break;
        case 7:
          nosaukums = "2.50";
          break;
        case 8:
          nosaukums = "2.40";
          break;
        case 9:
          nosaukums = "2.60";
          break;
        case 10:
          nosaukums = "3.20";
          break;
      }
    } else if (filt == 1) {
      switch (rowNum) {
        case 1:
          nosaukums = "0.70";
          break;
        case 2:
          nosaukums = "1.45";
          break;
        case 3:
          nosaukums = "2.50";
          break;
        case 4:
          nosaukums = "3.20";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 2) {
      switch (rowNum) {
        case 1:
          nosaukums = "0.80";
          break;
        case 2:
          nosaukums = "2.20";
          break;
        case 3:
          nosaukums = "2.40";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 3) {
      switch (rowNum) {
        case 1:
          nosaukums = "0.99";
          break;
        case 2:
          nosaukums = "1.80";
          break;
        case 3:
          nosaukums = "2.60";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 4) {
      switch (rowNum) {
        case 1:
          nosaukums = "0.70";
          break;
        case 2:
          nosaukums = "0.80";
          break;
        case 3:
          nosaukums = "0.99";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 5) {
      switch (rowNum) {
        case 1:
          nosaukums = "1.45";
          break;
        case 2:
          nosaukums = "1.80";
          break;
        case 3:
          nosaukums = "2.20";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 6) {
      switch (rowNum) {
        case 1:
          nosaukums = "2.40";
          break;
        case 2:
          nosaukums = "2.50";
          break;
        case 3:
          nosaukums = "2.60";
          break;
        case 4:
          nosaukums = "3.20";
          break;
        default:
          nosaukums = " ";
          break;
      }
    }
  } else if (kart == 1) {
    switch (rowNum) {
      case 1:
        nosaukums = "0.70";
        break;
      case 2:
        nosaukums = "0.80";
        break;
      case 3:
        nosaukums = "0.99";
        break;
      case 4:
        nosaukums = "1.45";
        break;
      case 5:
        nosaukums = "1.80";
        break;
      case 6:
        nosaukums = "2.20";
        break;
      case 7:
        nosaukums = "2.40";
        break;
      case 8:
        nosaukums = "2.50";
        break;
      case 9:
        nosaukums = "2.60";
        break;
      case 10:
        nosaukums = "3.20";
        break;
    }
  } else if (kart == 2) {
    switch (rowNum) {
      case 1:
        nosaukums = "0.70";
        break;
      case 2:
        nosaukums = "1.45";
        break;
      case 3:
        nosaukums = "2.50";
        break;
      case 4:
        nosaukums = "3.20";
        break;
      case 5:
        nosaukums = "0.99";
        break;
      case 6:
        nosaukums = "1.80";
        break;
      case 7:
        nosaukums = "2.60";
        break;
      case 8:
        nosaukums = "0.80";
        break;
      case 9:
        nosaukums = "2.20";
        break;
      case 10:
        nosaukums = "2.40";
        break;
    }
  } else if (kart == 3) {
    switch (rowNum) {
      case 1:
        nosaukums = "0.70";
        break;
      case 2:
        nosaukums = "1.45";
        break;
      case 3:
        nosaukums = "0.80";
        break;
      case 4:
        nosaukums = "1.80";
        break;
      case 5:
        nosaukums = "2.20";
        break;
      case 6:
        nosaukums = "2.40";
        break;
      case 7:
        nosaukums = "0.99";
        break;
      case 8:
        nosaukums = "2.60";
        break;
      case 9:
        nosaukums = "2.50";
        break;
      case 10:
        nosaukums = "3.20";
        break;
    }
  } else if (kart == 4) {
    switch (rowNum) {
      case 1:
        nosaukums = "2.40";
        break;
      case 2:
        nosaukums = "2.50";
        break;
      case 3:
        nosaukums = "2.60";
        break;
      case 4:
        nosaukums = "0.70";
        break;
      case 5:
        nosaukums = "0.80";
        break;
      case 6:
        nosaukums = "0.99";
        break;
      case 7:
        nosaukums = "1.45";
        break;
      case 8:
        nosaukums = "1.80";
        break;
      case 9:
        nosaukums = "2.20";
        break;
      case 10:
        nosaukums = "3.20";
        break;
    }
  }

  return nosaukums;
}

String? iegutVeikalu(
  int kart,
  int filt,
  int rowNum,
) {
  String nosaukums = "null";

  if (kart == 0) {
    if (filt == 0) {
      switch (rowNum) {
        case 1:
        case 4:
        case 7:
        case 10:
          nosaukums = "Maxima";
          break;
        case 2:
        case 5:
        case 8:
          nosaukums = "Rimi";
          break;
        case 3:
        case 6:
        case 9:
          nosaukums = "Mego";
          break;
      }
    } else if (filt == 1) {
      switch (rowNum) {
        case 1:
        case 2:
        case 3:
        case 4:
          nosaukums = "Maxima";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 2) {
      switch (rowNum) {
        case 1:
        case 2:
        case 3:
          nosaukums = "Rimi";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 3) {
      switch (rowNum) {
        case 1:
        case 2:
        case 3:
          nosaukums = "Mego";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 4) {
      switch (rowNum) {
        case 1:
          nosaukums = "Maxima";
          break;
        case 2:
          nosaukums = "Rimi";
          break;
        case 3:
          nosaukums = "Mego";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 5) {
      switch (rowNum) {
        case 1:
          nosaukums = "Maxima";
          break;
        case 2:
          nosaukums = "Mego";
          break;
        case 3:
          nosaukums = "Rimi";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 6) {
      switch (rowNum) {
        case 1:
          nosaukums = "Rimi";
          break;
        case 2:
        case 4:
          nosaukums = "Maxima";
          break;
        case 3:
          nosaukums = "Mego";
          break;
        default:
          nosaukums = " ";
          break;
      }
    }
  } else if (kart == 1) {
    switch (rowNum) {
      case 1:
      case 4:
      case 7:
      case 10:
        nosaukums = "Maxima";
        break;
      case 2:
      case 5:
      case 8:
        nosaukums = "Rimi";
        break;
      case 3:
      case 6:
      case 9:
        nosaukums = "Mego";
        break;
    }
  } else if (kart == 2) {
    switch (rowNum) {
      case 1:
      case 2:
      case 3:
      case 4:
        nosaukums = "Maxima";
        break;
      case 5:
      case 6:
      case 7:
        nosaukums = "Mego";
        break;
      case 8:
      case 9:
      case 10:
        nosaukums = "Rimi";
        break;
    }
  } else if (kart == 3) {
    switch (rowNum) {
      case 1:
      case 2:
      case 9:
      case 10:
        nosaukums = "Maxima";
        break;
      case 3:
      case 5:
      case 6:
        nosaukums = "Rimi";
        break;
      case 4:
      case 7:
      case 8:
        nosaukums = "Mego";
        break;
    }
  } else if (kart == 4) {
    switch (rowNum) {
      case 2:
      case 4:
      case 7:
      case 10:
        nosaukums = "Maxima";
        break;
      case 1:
      case 5:
      case 9:
        nosaukums = "Rimi";
        break;
      case 3:
      case 6:
      case 8:
        nosaukums = "Mego";
        break;
    }
  }

  return nosaukums;
}

String? iegutAtlaidi(
  int kart,
  int filt,
  int rowNum,
) {
  String nosaukums = " ";

  if (kart == 0) {
    if (filt == 0) {
      switch (rowNum) {
        case 1:
          nosaukums = "45";
          break;
        case 2:
          nosaukums = "30";
          break;
        case 3:
          nosaukums = "15";
          break;
        case 4:
          nosaukums = "40";
          break;
        case 5:
          nosaukums = "30";
          break;
        case 6:
          nosaukums = "30";
          break;
        case 7:
          nosaukums = "10";
          break;
        case 8:
          nosaukums = "20";
          break;
        case 9:
          nosaukums = "15";
          break;
        case 10:
          nosaukums = "10";
          break;
      }
    } else if (filt == 1) {
      switch (rowNum) {
        case 1:
          nosaukums = "45";
          break;
        case 2:
          nosaukums = "40";
          break;
        case 3:
          nosaukums = "10";
          break;
        case 4:
          nosaukums = "10";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 2) {
      switch (rowNum) {
        case 1:
          nosaukums = "30";
          break;
        case 2:
          nosaukums = "30";
          break;
        case 3:
          nosaukums = "20";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 3) {
      switch (rowNum) {
        case 1:
          nosaukums = "15";
          break;
        case 2:
          nosaukums = "30";
          break;
        case 3:
          nosaukums = "15";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 4) {
      switch (rowNum) {
        case 1:
          nosaukums = "45";
          break;
        case 2:
          nosaukums = "30";
          break;
        case 3:
          nosaukums = "15";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 5) {
      switch (rowNum) {
        case 1:
          nosaukums = "40";
          break;
        case 2:
          nosaukums = "30";
          break;
        case 3:
          nosaukums = "30";
          break;
        default:
          nosaukums = " ";
          break;
      }
    } else if (filt == 6) {
      switch (rowNum) {
        case 1:
          nosaukums = "20";
          break;
        case 2:
          nosaukums = "10";
          break;
        case 3:
          nosaukums = "15";
          break;
        case 4:
          nosaukums = "10";
          break;
        default:
          nosaukums = " ";
          break;
      }
    }
  } else if (kart == 1) {
    switch (rowNum) {
      case 1:
        nosaukums = "45";
        break;
      case 2:
        nosaukums = "30";
        break;
      case 3:
        nosaukums = "15";
        break;
      case 4:
        nosaukums = "40";
        break;
      case 5:
        nosaukums = "30";
        break;
      case 6:
        nosaukums = "30";
        break;
      case 7:
        nosaukums = "20";
        break;
      case 8:
        nosaukums = "10";
        break;
      case 9:
        nosaukums = "15";
        break;
      case 10:
        nosaukums = "10";
        break;
    }
  } else if (kart == 2) {
    switch (rowNum) {
      case 1:
        nosaukums = "45";
        break;
      case 2:
        nosaukums = "40";
        break;
      case 3:
        nosaukums = "10";
        break;
      case 4:
        nosaukums = "10";
        break;
      case 5:
        nosaukums = "15";
        break;
      case 6:
        nosaukums = "30";
        break;
      case 7:
        nosaukums = "15";
        break;
      case 8:
        nosaukums = "30";
        break;
      case 9:
        nosaukums = "30";
        break;
      case 10:
        nosaukums = "20";
        break;
    }
  } else if (kart == 3) {
    switch (rowNum) {
      case 1:
        nosaukums = "45";
        break;
      case 2:
        nosaukums = "40";
        break;
      case 3:
        nosaukums = "30";
        break;
      case 4:
        nosaukums = "30";
        break;
      case 5:
        nosaukums = "30";
        break;
      case 6:
        nosaukums = "20";
        break;
      case 7:
        nosaukums = "15";
        break;
      case 8:
        nosaukums = "15";
        break;
      case 9:
        nosaukums = "15";
        break;
      case 10:
        nosaukums = "15";
        break;
    }
  } else if (kart == 4) {
    switch (rowNum) {
      case 1:
        nosaukums = "45";
        break;
      case 2:
        nosaukums = "30";
        break;
      case 3:
        nosaukums = "15";
        break;
      case 4:
        nosaukums = "40";
        break;
      case 5:
        nosaukums = "30";
        break;
      case 6:
        nosaukums = "30";
        break;
      case 7:
        nosaukums = "20";
        break;
      case 8:
        nosaukums = "10";
        break;
      case 9:
        nosaukums = "15";
        break;
      case 10:
        nosaukums = "10";
        break;
    }
  }

  return nosaukums;
}
