import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _kartot = prefs.getInt('ff_kartot') ?? _kartot;
    });
    _safeInit(() {
      _filtret = prefs.getInt('ff_filtret') ?? _filtret;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  int _kartot = 0;
  int get kartot => _kartot;
  set kartot(int value) {
    _kartot = value;
    prefs.setInt('ff_kartot', value);
  }

  int _filtret = 0;
  int get filtret => _filtret;
  set filtret(int value) {
    _filtret = value;
    prefs.setInt('ff_filtret', value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
