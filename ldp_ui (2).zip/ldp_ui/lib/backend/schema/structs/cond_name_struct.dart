// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CondNameStruct extends BaseStruct {
  CondNameStruct({
    int? kartosana,
    int? filtrs,
  })  : _kartosana = kartosana,
        _filtrs = filtrs;

  // "Kartosana" field.
  int? _kartosana;
  int get kartosana => _kartosana ?? 0;
  set kartosana(int? val) => _kartosana = val;

  void incrementKartosana(int amount) => kartosana = kartosana + amount;

  bool hasKartosana() => _kartosana != null;

  // "filtrs" field.
  int? _filtrs;
  int get filtrs => _filtrs ?? 0;
  set filtrs(int? val) => _filtrs = val;

  void incrementFiltrs(int amount) => filtrs = filtrs + amount;

  bool hasFiltrs() => _filtrs != null;

  static CondNameStruct fromMap(Map<String, dynamic> data) => CondNameStruct(
        kartosana: castToType<int>(data['Kartosana']),
        filtrs: castToType<int>(data['filtrs']),
      );

  static CondNameStruct? maybeFromMap(dynamic data) =>
      data is Map ? CondNameStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'Kartosana': _kartosana,
        'filtrs': _filtrs,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Kartosana': serializeParam(
          _kartosana,
          ParamType.int,
        ),
        'filtrs': serializeParam(
          _filtrs,
          ParamType.int,
        ),
      }.withoutNulls;

  static CondNameStruct fromSerializableMap(Map<String, dynamic> data) =>
      CondNameStruct(
        kartosana: deserializeParam(
          data['Kartosana'],
          ParamType.int,
          false,
        ),
        filtrs: deserializeParam(
          data['filtrs'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'CondNameStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is CondNameStruct &&
        kartosana == other.kartosana &&
        filtrs == other.filtrs;
  }

  @override
  int get hashCode => const ListEquality().hash([kartosana, filtrs]);
}

CondNameStruct createCondNameStruct({
  int? kartosana,
  int? filtrs,
}) =>
    CondNameStruct(
      kartosana: kartosana,
      filtrs: filtrs,
    );
