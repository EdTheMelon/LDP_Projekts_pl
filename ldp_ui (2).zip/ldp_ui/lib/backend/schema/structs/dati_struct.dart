// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DatiStruct extends BaseStruct {
  DatiStruct({
    String? baltmaize,
    String? siers,
    String? aboluSula,
    String? vinoguSula,
    String? veikals1,
    String? veikals2,
    String? veikals3,
    double? cena1,
    double? cena2,
    double? cena3,
    double? cena4,
    double? cena5,
    double? cena6,
    double? cena7,
    double? cena8,
    double? cena9,
    double? cena10,
    int? atlaide1,
    int? atlaide2,
    int? atlaide3,
    int? atlaide4,
    int? atlaide5,
    int? atlaide6,
    int? atlaide7,
    int? atlaide8,
    int? atlaide9,
    int? atlaide10,
    String? kategorija1,
    String? kategorija2,
    String? kategorija3,
  })  : _baltmaize = baltmaize,
        _siers = siers,
        _aboluSula = aboluSula,
        _vinoguSula = vinoguSula,
        _veikals1 = veikals1,
        _veikals2 = veikals2,
        _veikals3 = veikals3,
        _cena1 = cena1,
        _cena2 = cena2,
        _cena3 = cena3,
        _cena4 = cena4,
        _cena5 = cena5,
        _cena6 = cena6,
        _cena7 = cena7,
        _cena8 = cena8,
        _cena9 = cena9,
        _cena10 = cena10,
        _atlaide1 = atlaide1,
        _atlaide2 = atlaide2,
        _atlaide3 = atlaide3,
        _atlaide4 = atlaide4,
        _atlaide5 = atlaide5,
        _atlaide6 = atlaide6,
        _atlaide7 = atlaide7,
        _atlaide8 = atlaide8,
        _atlaide9 = atlaide9,
        _atlaide10 = atlaide10,
        _kategorija1 = kategorija1,
        _kategorija2 = kategorija2,
        _kategorija3 = kategorija3;

  // "baltmaize" field.
  String? _baltmaize;
  String get baltmaize => _baltmaize ?? 'Baltmaize';
  set baltmaize(String? val) => _baltmaize = val;

  bool hasBaltmaize() => _baltmaize != null;

  // "siers" field.
  String? _siers;
  String get siers => _siers ?? 'Holandes siers';
  set siers(String? val) => _siers = val;

  bool hasSiers() => _siers != null;

  // "abolu_sula" field.
  String? _aboluSula;
  String get aboluSula => _aboluSula ?? 'Ābolu sula';
  set aboluSula(String? val) => _aboluSula = val;

  bool hasAboluSula() => _aboluSula != null;

  // "vinogu_sula" field.
  String? _vinoguSula;
  String get vinoguSula => _vinoguSula ?? 'Vīnogu sula';
  set vinoguSula(String? val) => _vinoguSula = val;

  bool hasVinoguSula() => _vinoguSula != null;

  // "Veikals_1" field.
  String? _veikals1;
  String get veikals1 => _veikals1 ?? 'Maxima';
  set veikals1(String? val) => _veikals1 = val;

  bool hasVeikals1() => _veikals1 != null;

  // "veikals_2" field.
  String? _veikals2;
  String get veikals2 => _veikals2 ?? 'Rimi';
  set veikals2(String? val) => _veikals2 = val;

  bool hasVeikals2() => _veikals2 != null;

  // "veikals_3" field.
  String? _veikals3;
  String get veikals3 => _veikals3 ?? 'Mego';
  set veikals3(String? val) => _veikals3 = val;

  bool hasVeikals3() => _veikals3 != null;

  // "cena_1" field.
  double? _cena1;
  double get cena1 => _cena1 ?? 0.70;
  set cena1(double? val) => _cena1 = val;

  void incrementCena1(double amount) => cena1 = cena1 + amount;

  bool hasCena1() => _cena1 != null;

  // "cena_2" field.
  double? _cena2;
  double get cena2 => _cena2 ?? 0.80;
  set cena2(double? val) => _cena2 = val;

  void incrementCena2(double amount) => cena2 = cena2 + amount;

  bool hasCena2() => _cena2 != null;

  // "cena_3" field.
  double? _cena3;
  double get cena3 => _cena3 ?? 0.99;
  set cena3(double? val) => _cena3 = val;

  void incrementCena3(double amount) => cena3 = cena3 + amount;

  bool hasCena3() => _cena3 != null;

  // "cena_4" field.
  double? _cena4;
  double get cena4 => _cena4 ?? 1.45;
  set cena4(double? val) => _cena4 = val;

  void incrementCena4(double amount) => cena4 = cena4 + amount;

  bool hasCena4() => _cena4 != null;

  // "cena_5" field.
  double? _cena5;
  double get cena5 => _cena5 ?? 2.20;
  set cena5(double? val) => _cena5 = val;

  void incrementCena5(double amount) => cena5 = cena5 + amount;

  bool hasCena5() => _cena5 != null;

  // "cena_6" field.
  double? _cena6;
  double get cena6 => _cena6 ?? 1.80;
  set cena6(double? val) => _cena6 = val;

  void incrementCena6(double amount) => cena6 = cena6 + amount;

  bool hasCena6() => _cena6 != null;

  // "cena_7" field.
  double? _cena7;
  double get cena7 => _cena7 ?? 2.50;
  set cena7(double? val) => _cena7 = val;

  void incrementCena7(double amount) => cena7 = cena7 + amount;

  bool hasCena7() => _cena7 != null;

  // "cena_8" field.
  double? _cena8;
  double get cena8 => _cena8 ?? 2.40;
  set cena8(double? val) => _cena8 = val;

  void incrementCena8(double amount) => cena8 = cena8 + amount;

  bool hasCena8() => _cena8 != null;

  // "cena_9" field.
  double? _cena9;
  double get cena9 => _cena9 ?? 2.60;
  set cena9(double? val) => _cena9 = val;

  void incrementCena9(double amount) => cena9 = cena9 + amount;

  bool hasCena9() => _cena9 != null;

  // "cena_10" field.
  double? _cena10;
  double get cena10 => _cena10 ?? 3.20;
  set cena10(double? val) => _cena10 = val;

  void incrementCena10(double amount) => cena10 = cena10 + amount;

  bool hasCena10() => _cena10 != null;

  // "atlaide_1" field.
  int? _atlaide1;
  int get atlaide1 => _atlaide1 ?? 45;
  set atlaide1(int? val) => _atlaide1 = val;

  void incrementAtlaide1(int amount) => atlaide1 = atlaide1 + amount;

  bool hasAtlaide1() => _atlaide1 != null;

  // "atlaide_2" field.
  int? _atlaide2;
  int get atlaide2 => _atlaide2 ?? 30;
  set atlaide2(int? val) => _atlaide2 = val;

  void incrementAtlaide2(int amount) => atlaide2 = atlaide2 + amount;

  bool hasAtlaide2() => _atlaide2 != null;

  // "atlaide_3" field.
  int? _atlaide3;
  int get atlaide3 => _atlaide3 ?? 15;
  set atlaide3(int? val) => _atlaide3 = val;

  void incrementAtlaide3(int amount) => atlaide3 = atlaide3 + amount;

  bool hasAtlaide3() => _atlaide3 != null;

  // "atlaide_4" field.
  int? _atlaide4;
  int get atlaide4 => _atlaide4 ?? 40;
  set atlaide4(int? val) => _atlaide4 = val;

  void incrementAtlaide4(int amount) => atlaide4 = atlaide4 + amount;

  bool hasAtlaide4() => _atlaide4 != null;

  // "atlaide_5" field.
  int? _atlaide5;
  int get atlaide5 => _atlaide5 ?? 30;
  set atlaide5(int? val) => _atlaide5 = val;

  void incrementAtlaide5(int amount) => atlaide5 = atlaide5 + amount;

  bool hasAtlaide5() => _atlaide5 != null;

  // "atlaide_6" field.
  int? _atlaide6;
  int get atlaide6 => _atlaide6 ?? 30;
  set atlaide6(int? val) => _atlaide6 = val;

  void incrementAtlaide6(int amount) => atlaide6 = atlaide6 + amount;

  bool hasAtlaide6() => _atlaide6 != null;

  // "atlaide_7" field.
  int? _atlaide7;
  int get atlaide7 => _atlaide7 ?? 10;
  set atlaide7(int? val) => _atlaide7 = val;

  void incrementAtlaide7(int amount) => atlaide7 = atlaide7 + amount;

  bool hasAtlaide7() => _atlaide7 != null;

  // "atlaide_8" field.
  int? _atlaide8;
  int get atlaide8 => _atlaide8 ?? 20;
  set atlaide8(int? val) => _atlaide8 = val;

  void incrementAtlaide8(int amount) => atlaide8 = atlaide8 + amount;

  bool hasAtlaide8() => _atlaide8 != null;

  // "atlaide_9" field.
  int? _atlaide9;
  int get atlaide9 => _atlaide9 ?? 15;
  set atlaide9(int? val) => _atlaide9 = val;

  void incrementAtlaide9(int amount) => atlaide9 = atlaide9 + amount;

  bool hasAtlaide9() => _atlaide9 != null;

  // "atlaide_10" field.
  int? _atlaide10;
  int get atlaide10 => _atlaide10 ?? 10;
  set atlaide10(int? val) => _atlaide10 = val;

  void incrementAtlaide10(int amount) => atlaide10 = atlaide10 + amount;

  bool hasAtlaide10() => _atlaide10 != null;

  // "kategorija_1" field.
  String? _kategorija1;
  String get kategorija1 => _kategorija1 ?? 'maize';
  set kategorija1(String? val) => _kategorija1 = val;

  bool hasKategorija1() => _kategorija1 != null;

  // "kategorija_2" field.
  String? _kategorija2;
  String get kategorija2 => _kategorija2 ?? 'siers';
  set kategorija2(String? val) => _kategorija2 = val;

  bool hasKategorija2() => _kategorija2 != null;

  // "kategorija_3" field.
  String? _kategorija3;
  String get kategorija3 => _kategorija3 ?? 'sula';
  set kategorija3(String? val) => _kategorija3 = val;

  bool hasKategorija3() => _kategorija3 != null;

  static DatiStruct fromMap(Map<String, dynamic> data) => DatiStruct(
        baltmaize: data['baltmaize'] as String?,
        siers: data['siers'] as String?,
        aboluSula: data['abolu_sula'] as String?,
        vinoguSula: data['vinogu_sula'] as String?,
        veikals1: data['Veikals_1'] as String?,
        veikals2: data['veikals_2'] as String?,
        veikals3: data['veikals_3'] as String?,
        cena1: castToType<double>(data['cena_1']),
        cena2: castToType<double>(data['cena_2']),
        cena3: castToType<double>(data['cena_3']),
        cena4: castToType<double>(data['cena_4']),
        cena5: castToType<double>(data['cena_5']),
        cena6: castToType<double>(data['cena_6']),
        cena7: castToType<double>(data['cena_7']),
        cena8: castToType<double>(data['cena_8']),
        cena9: castToType<double>(data['cena_9']),
        cena10: castToType<double>(data['cena_10']),
        atlaide1: castToType<int>(data['atlaide_1']),
        atlaide2: castToType<int>(data['atlaide_2']),
        atlaide3: castToType<int>(data['atlaide_3']),
        atlaide4: castToType<int>(data['atlaide_4']),
        atlaide5: castToType<int>(data['atlaide_5']),
        atlaide6: castToType<int>(data['atlaide_6']),
        atlaide7: castToType<int>(data['atlaide_7']),
        atlaide8: castToType<int>(data['atlaide_8']),
        atlaide9: castToType<int>(data['atlaide_9']),
        atlaide10: castToType<int>(data['atlaide_10']),
        kategorija1: data['kategorija_1'] as String?,
        kategorija2: data['kategorija_2'] as String?,
        kategorija3: data['kategorija_3'] as String?,
      );

  static DatiStruct? maybeFromMap(dynamic data) =>
      data is Map ? DatiStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'baltmaize': _baltmaize,
        'siers': _siers,
        'abolu_sula': _aboluSula,
        'vinogu_sula': _vinoguSula,
        'Veikals_1': _veikals1,
        'veikals_2': _veikals2,
        'veikals_3': _veikals3,
        'cena_1': _cena1,
        'cena_2': _cena2,
        'cena_3': _cena3,
        'cena_4': _cena4,
        'cena_5': _cena5,
        'cena_6': _cena6,
        'cena_7': _cena7,
        'cena_8': _cena8,
        'cena_9': _cena9,
        'cena_10': _cena10,
        'atlaide_1': _atlaide1,
        'atlaide_2': _atlaide2,
        'atlaide_3': _atlaide3,
        'atlaide_4': _atlaide4,
        'atlaide_5': _atlaide5,
        'atlaide_6': _atlaide6,
        'atlaide_7': _atlaide7,
        'atlaide_8': _atlaide8,
        'atlaide_9': _atlaide9,
        'atlaide_10': _atlaide10,
        'kategorija_1': _kategorija1,
        'kategorija_2': _kategorija2,
        'kategorija_3': _kategorija3,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'baltmaize': serializeParam(
          _baltmaize,
          ParamType.String,
        ),
        'siers': serializeParam(
          _siers,
          ParamType.String,
        ),
        'abolu_sula': serializeParam(
          _aboluSula,
          ParamType.String,
        ),
        'vinogu_sula': serializeParam(
          _vinoguSula,
          ParamType.String,
        ),
        'Veikals_1': serializeParam(
          _veikals1,
          ParamType.String,
        ),
        'veikals_2': serializeParam(
          _veikals2,
          ParamType.String,
        ),
        'veikals_3': serializeParam(
          _veikals3,
          ParamType.String,
        ),
        'cena_1': serializeParam(
          _cena1,
          ParamType.double,
        ),
        'cena_2': serializeParam(
          _cena2,
          ParamType.double,
        ),
        'cena_3': serializeParam(
          _cena3,
          ParamType.double,
        ),
        'cena_4': serializeParam(
          _cena4,
          ParamType.double,
        ),
        'cena_5': serializeParam(
          _cena5,
          ParamType.double,
        ),
        'cena_6': serializeParam(
          _cena6,
          ParamType.double,
        ),
        'cena_7': serializeParam(
          _cena7,
          ParamType.double,
        ),
        'cena_8': serializeParam(
          _cena8,
          ParamType.double,
        ),
        'cena_9': serializeParam(
          _cena9,
          ParamType.double,
        ),
        'cena_10': serializeParam(
          _cena10,
          ParamType.double,
        ),
        'atlaide_1': serializeParam(
          _atlaide1,
          ParamType.int,
        ),
        'atlaide_2': serializeParam(
          _atlaide2,
          ParamType.int,
        ),
        'atlaide_3': serializeParam(
          _atlaide3,
          ParamType.int,
        ),
        'atlaide_4': serializeParam(
          _atlaide4,
          ParamType.int,
        ),
        'atlaide_5': serializeParam(
          _atlaide5,
          ParamType.int,
        ),
        'atlaide_6': serializeParam(
          _atlaide6,
          ParamType.int,
        ),
        'atlaide_7': serializeParam(
          _atlaide7,
          ParamType.int,
        ),
        'atlaide_8': serializeParam(
          _atlaide8,
          ParamType.int,
        ),
        'atlaide_9': serializeParam(
          _atlaide9,
          ParamType.int,
        ),
        'atlaide_10': serializeParam(
          _atlaide10,
          ParamType.int,
        ),
        'kategorija_1': serializeParam(
          _kategorija1,
          ParamType.String,
        ),
        'kategorija_2': serializeParam(
          _kategorija2,
          ParamType.String,
        ),
        'kategorija_3': serializeParam(
          _kategorija3,
          ParamType.String,
        ),
      }.withoutNulls;

  static DatiStruct fromSerializableMap(Map<String, dynamic> data) =>
      DatiStruct(
        baltmaize: deserializeParam(
          data['baltmaize'],
          ParamType.String,
          false,
        ),
        siers: deserializeParam(
          data['siers'],
          ParamType.String,
          false,
        ),
        aboluSula: deserializeParam(
          data['abolu_sula'],
          ParamType.String,
          false,
        ),
        vinoguSula: deserializeParam(
          data['vinogu_sula'],
          ParamType.String,
          false,
        ),
        veikals1: deserializeParam(
          data['Veikals_1'],
          ParamType.String,
          false,
        ),
        veikals2: deserializeParam(
          data['veikals_2'],
          ParamType.String,
          false,
        ),
        veikals3: deserializeParam(
          data['veikals_3'],
          ParamType.String,
          false,
        ),
        cena1: deserializeParam(
          data['cena_1'],
          ParamType.double,
          false,
        ),
        cena2: deserializeParam(
          data['cena_2'],
          ParamType.double,
          false,
        ),
        cena3: deserializeParam(
          data['cena_3'],
          ParamType.double,
          false,
        ),
        cena4: deserializeParam(
          data['cena_4'],
          ParamType.double,
          false,
        ),
        cena5: deserializeParam(
          data['cena_5'],
          ParamType.double,
          false,
        ),
        cena6: deserializeParam(
          data['cena_6'],
          ParamType.double,
          false,
        ),
        cena7: deserializeParam(
          data['cena_7'],
          ParamType.double,
          false,
        ),
        cena8: deserializeParam(
          data['cena_8'],
          ParamType.double,
          false,
        ),
        cena9: deserializeParam(
          data['cena_9'],
          ParamType.double,
          false,
        ),
        cena10: deserializeParam(
          data['cena_10'],
          ParamType.double,
          false,
        ),
        atlaide1: deserializeParam(
          data['atlaide_1'],
          ParamType.int,
          false,
        ),
        atlaide2: deserializeParam(
          data['atlaide_2'],
          ParamType.int,
          false,
        ),
        atlaide3: deserializeParam(
          data['atlaide_3'],
          ParamType.int,
          false,
        ),
        atlaide4: deserializeParam(
          data['atlaide_4'],
          ParamType.int,
          false,
        ),
        atlaide5: deserializeParam(
          data['atlaide_5'],
          ParamType.int,
          false,
        ),
        atlaide6: deserializeParam(
          data['atlaide_6'],
          ParamType.int,
          false,
        ),
        atlaide7: deserializeParam(
          data['atlaide_7'],
          ParamType.int,
          false,
        ),
        atlaide8: deserializeParam(
          data['atlaide_8'],
          ParamType.int,
          false,
        ),
        atlaide9: deserializeParam(
          data['atlaide_9'],
          ParamType.int,
          false,
        ),
        atlaide10: deserializeParam(
          data['atlaide_10'],
          ParamType.int,
          false,
        ),
        kategorija1: deserializeParam(
          data['kategorija_1'],
          ParamType.String,
          false,
        ),
        kategorija2: deserializeParam(
          data['kategorija_2'],
          ParamType.String,
          false,
        ),
        kategorija3: deserializeParam(
          data['kategorija_3'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'DatiStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is DatiStruct &&
        baltmaize == other.baltmaize &&
        siers == other.siers &&
        aboluSula == other.aboluSula &&
        vinoguSula == other.vinoguSula &&
        veikals1 == other.veikals1 &&
        veikals2 == other.veikals2 &&
        veikals3 == other.veikals3 &&
        cena1 == other.cena1 &&
        cena2 == other.cena2 &&
        cena3 == other.cena3 &&
        cena4 == other.cena4 &&
        cena5 == other.cena5 &&
        cena6 == other.cena6 &&
        cena7 == other.cena7 &&
        cena8 == other.cena8 &&
        cena9 == other.cena9 &&
        cena10 == other.cena10 &&
        atlaide1 == other.atlaide1 &&
        atlaide2 == other.atlaide2 &&
        atlaide3 == other.atlaide3 &&
        atlaide4 == other.atlaide4 &&
        atlaide5 == other.atlaide5 &&
        atlaide6 == other.atlaide6 &&
        atlaide7 == other.atlaide7 &&
        atlaide8 == other.atlaide8 &&
        atlaide9 == other.atlaide9 &&
        atlaide10 == other.atlaide10 &&
        kategorija1 == other.kategorija1 &&
        kategorija2 == other.kategorija2 &&
        kategorija3 == other.kategorija3;
  }

  @override
  int get hashCode => const ListEquality().hash([
        baltmaize,
        siers,
        aboluSula,
        vinoguSula,
        veikals1,
        veikals2,
        veikals3,
        cena1,
        cena2,
        cena3,
        cena4,
        cena5,
        cena6,
        cena7,
        cena8,
        cena9,
        cena10,
        atlaide1,
        atlaide2,
        atlaide3,
        atlaide4,
        atlaide5,
        atlaide6,
        atlaide7,
        atlaide8,
        atlaide9,
        atlaide10,
        kategorija1,
        kategorija2,
        kategorija3
      ]);
}

DatiStruct createDatiStruct({
  String? baltmaize,
  String? siers,
  String? aboluSula,
  String? vinoguSula,
  String? veikals1,
  String? veikals2,
  String? veikals3,
  double? cena1,
  double? cena2,
  double? cena3,
  double? cena4,
  double? cena5,
  double? cena6,
  double? cena7,
  double? cena8,
  double? cena9,
  double? cena10,
  int? atlaide1,
  int? atlaide2,
  int? atlaide3,
  int? atlaide4,
  int? atlaide5,
  int? atlaide6,
  int? atlaide7,
  int? atlaide8,
  int? atlaide9,
  int? atlaide10,
  String? kategorija1,
  String? kategorija2,
  String? kategorija3,
}) =>
    DatiStruct(
      baltmaize: baltmaize,
      siers: siers,
      aboluSula: aboluSula,
      vinoguSula: vinoguSula,
      veikals1: veikals1,
      veikals2: veikals2,
      veikals3: veikals3,
      cena1: cena1,
      cena2: cena2,
      cena3: cena3,
      cena4: cena4,
      cena5: cena5,
      cena6: cena6,
      cena7: cena7,
      cena8: cena8,
      cena9: cena9,
      cena10: cena10,
      atlaide1: atlaide1,
      atlaide2: atlaide2,
      atlaide3: atlaide3,
      atlaide4: atlaide4,
      atlaide5: atlaide5,
      atlaide6: atlaide6,
      atlaide7: atlaide7,
      atlaide8: atlaide8,
      atlaide9: atlaide9,
      atlaide10: atlaide10,
      kategorija1: kategorija1,
      kategorija2: kategorija2,
      kategorija3: kategorija3,
    );
